/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
    "egg salad": "Egg salad, can be kept refrigerated for 3 to 5 days at 40 degrees fahrenheit or below. They do not freeze well. ",
    "chicken salad": "Chicken salad, can be kept refrigerated for 3 to 5 days at 40 degrees fahrenheit or below. They do not freeze well.",
    "ham salad": "ham salad, can be kept refrigerated for 3 to 5 days at 40 degrees fahrenheit or below. They do not freeze well.",
    "tuna salad": "tuna salad, can be kept refrigerated for 3 to 5 days at 40 degrees fahrenheit or below. They do not freeze well.",
    "macaroni salad": "macaroni salad, can be kept refrigerated for 3 to 5 days at 40 degrees fahrenheit  or below. They do not freeze well.",
    "hot dog": "hot dog opened package, can be kept refrigerated 1 week at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "hot dog": "hot dog unopened package, can be kept refrigerated 2 weeks at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "hot dogs": "hot dogs opened package, can be kept refrigerated 1 week at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "hot dogs": "hot dogs unopened package, can be kept refrigerated 2 weeks at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "luncheon meat": "luncheon meat opened package or deli sliced, can be kept refrigerated 3 to 5 days at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "luncheon meat": "luncheon meat unopened package or deli sliced, can be kept refrigerated 2 weeks at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "sandwich meat": "sandwich meat opened package or deli sliced, can be kept refrigerated 3 to 5 days at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely.",
    "sandwich meat": "v meat unopened package or deli sliced, can be kept refrigerated 2 weeks at 40 degrees fahrenheit or below. They will remain at good quaility for 1 to 2 months at zero degrees or below but can be kept frozen indefinitely."
};
